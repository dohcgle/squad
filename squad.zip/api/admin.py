from django.contrib import admin
from .models import *

admin.site.register(Members)
admin.site.register(Squad)
admin.site.register(Power)